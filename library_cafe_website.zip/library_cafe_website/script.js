// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");

menuToggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "×" : "☰";
});

// Close the mobile menu after choosing a section
nav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
    menuToggle.textContent = "☰";
  });
});

// Keep the footer year current
document.getElementById("year").textContent = new Date().getFullYear();

// Front-end newsletter demo. Connect this to an email marketing service to collect real subscribers.
const newsletter = document.getElementById("newsletter");
const emailInput = document.getElementById("email");
const formMessage = document.getElementById("formMessage");

newsletter.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!emailInput.checkValidity()) {
    emailInput.reportValidity();
    return;
  }
  formMessage.textContent = "Thanks for your interest! Connect an email service to save subscriptions.";
  newsletter.reset();
});
