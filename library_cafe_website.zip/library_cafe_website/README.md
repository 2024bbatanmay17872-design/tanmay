# Pages & Pour — Library Café Website

A responsive landing page starter built with plain HTML, CSS, and JavaScript.

## Run it
1. Extract the ZIP.
2. Keep `index.html`, `style.css`, and `script.js` in the same folder.
3. Open `index.html` in a browser.

## Customize before publishing
- Replace the demo business name "Pages & Pour" with your brand.
- Update address, phone/email, hours, menu prices, events, and membership details.
- Replace the Unsplash image URLs with your own licensed café/library photos if preferred.
- The newsletter form is front-end only; connect it to an email marketing service or backend to collect real subscribers.
- Update the sample event dates and demo menu prices.
- For a public website, deploy the files to a hosting provider and configure your domain.

## Files
- `index.html` — page content
- `style.css` — layout, colors, and responsive styling
- `script.js` — mobile menu, current year, and demo newsletter interaction
